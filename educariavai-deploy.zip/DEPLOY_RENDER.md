# 🚀 Tutorial: Deploy no Render

## ✅ Pré-requisitos

Você precisa ter:
- ✅ Conta no GitHub (crie em [github.com](https://github.com))
- ✅ Conta no Render (crie em [render.com](https://render.com))
- ✅ Seu repositório com o projeto no GitHub
- ✅ Sua chave `GROQ_API_KEY`

---

## 📋 Passo 1: Prepare o código no GitHub

### 1.1 - Crie um repositório no GitHub
1. Vá em [github.com/new](https://github.com/new)
2. Nome do repositório: `educariavai` (ou o nome que quiser)
3. Descrição: `Clube de Checagem de Fake News com IA`
4. Clique em "Create repository"

### 1.2 - Envie seu código para o GitHub
No PowerShell, na pasta `Educar-IA`:

```powershell
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/SEUUSUARIO/educariavai.git
git push -u origin main
```

Se não tem Git instalado, [baixe aqui](https://git-scm.com/).

---

## 🔑 Passo 2: Crie conta no Render

1. Vá em [render.com](https://render.com)
2. Clique em **"Sign up"**
3. Use seu email ou conecte com GitHub
4. Confirme seu email

---

## 🌐 Passo 3: Crie um novo Web Service no Render

### 3.1 - Conecte seu repositório GitHub
1. Vá em [dashboard.render.com](https://dashboard.render.com)
2. Clique no botão **"New +"** no canto superior esquerdo
3. Selecione **"Web Service"**
4. Clique em **"Connect a repository"**
5. Procure por `educariavai` (seu repositório)
6. Clique em **"Connect"**

### 3.2 - Configure o serviço
Preencha os campos assim:

| Campo | Valor |
|-------|-------|
| **Name** | `educariavai` (ou seu nome) |
| **Environment** | `Node` |
| **Region** | `São Paulo (sa-east-1)` ou sua região |
| **Branch** | `main` |
| **Build Command** | `npm install` |
| **Start Command** | `npm start` |
| **Plan** | `Free` (gratuito) |

---

## 🔐 Passo 4: Configure a chave Groq API

1. Na mesma página, desça até **"Environment"**
2. Clique em **"Add Environment Variable"**
3. Preencha assim:

   | Campo | Valor |
   |-------|-------|
   | **Key** | `GROQ_API_KEY` |
   | **Value** | `sua_chave_groq_aqui` |

4. Clique em **"Save"**

Se não tem chave Groq:
- Vá em [console.groq.com](https://console.groq.com)
- Crie uma conta grátis
- Copie sua API Key
- Cole aqui

---

## 🚀 Passo 5: Deploy

1. Clique no botão **"Create Web Service"** (ou "Deploy")
2. Espere o deploy terminar (pode levar 5-10 minutos)
3. Você verá uma tela com:
   ```
   ✓ Build successful
   ✓ Running
   ```

4. Copie a URL que aparece no topo (algo como: `https://educariavai.onrender.com`)

---

## ✅ Pronto! Site online!

Abra a URL no navegador e compartilhe com todo mundo! 🎉

---

## 📝 Próximas atualizações

Sempre que você quiser atualizar o site:

1. Faça as mudanças no código localmente
2. No PowerShell:
   ```powershell
   git add .
   git commit -m "Descrição das mudanças"
   git push origin main
   ```
3. O Render faz deploy automaticamente! ✨

---

## ⚠️ Solução de Problemas

### "Build failed" ou erro vermelho
1. Verifique se a chave `GROQ_API_KEY` está correta
2. Verifique se o `package.json` existe na raiz
3. Verifique se o `servidor/server.js` existe

### Site lento ou parado
- Pode estar dormindo (plano free dorme após 15 minutos sem uso)
- Solução: clique para acordar ou upgrade para plano pago

### "Cannot find module"
- Algo não foi instalado corretamente
- Solução: 
  1. Vá no Render Dashboard
  2. Clique em "Redeploy"
  3. Aguarde novo deploy

### Erro ao enviar para GitHub
- Verifique se tem acesso ao repositório
- Use: `git remote -v` para ver se a URL está correta

---

## 🎯 Resumo dos 5 passos

1. ✅ GitHub: subir código
2. ✅ Render: criar conta
3. ✅ Render: conectar repositório
4. ✅ Render: configurar `GROQ_API_KEY`
5. ✅ Deploy automático!

---

**Site no ar! 🚀 Compartilhe a URL com todos!**

Exemplo: `https://seu-site.onrender.com`
